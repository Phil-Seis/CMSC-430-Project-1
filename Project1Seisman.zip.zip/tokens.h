// CMSC 430 Compiler Theory and Design
// Project 1 - Philip M. Seisman
// UMGC CITE
// Spring 2025

// This file contains the enumerated type definition for tokens

enum Tokens {ADDOP = 256, MULOP, ANDOP, RELOP, ARROW, OROP, NOTOP, BEGIN_, CASE, CHARACTER, END, ELSE, ELSIF, ENDFOLD, ENDIF, FOLD,
     ENDSWITCH, FUNCTION, INTEGER, IS, LIST, OF, OTHERS, RETURNS, REMOP, EXPOP, NEGOP, SWITCH, WHEN, IF, LEFT, REAL, RIGHT, THEN,
     IDENTIFIER, INT_LITERAL, CHAR_LITERAL, FLOAT_LITERAL, REAL_LITERAL};
