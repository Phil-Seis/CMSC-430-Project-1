// CMSC 430 Compiler Theory and Design
// Project 1 - Philip M. Seisman
// UMGC CITE
// Spring 2025

// This file contains the bodies of the functions that produce the 
// compilation listing

#include <cstdio>
#include <string>
#include <queue>

using namespace std;

#include "listing.h"

static int lexicalErrors = 0;
static int syntacticErrors = 0;
static int semanticErrors = 0;

static queue<string> errorQueue;
static int lineNumber;

static void displayErrors();

void firstLine() {
    lineNumber = 1;
    printf("\n%4d  ", lineNumber);
}

void nextLine() {
    displayErrors();
    lineNumber++;
    printf("%4d  ", lineNumber);
}

int lastLine() {
    printf("\r");
    displayErrors();
    printf("     \n");

    int totalErrors = lexicalErrors + syntacticErrors + semanticErrors;


    if (totalErrors > 0) {
        printf("Compilation failed with errors:\n");
        printf("  Lexical Errors: %d\n", lexicalErrors);
        printf("  Syntax Errors: %d\n", syntacticErrors);
        printf("  Semantic Errors: %d\n", semanticErrors);
    } else {
        printf("Compilation Successful\n");
    }

    return totalErrors;
}

void appendError(ErrorCategories errorCategory, string message) {
    string messages[] = {
        "Lexical Error, Invalid Character ",
        "Syntactic Error, ",
        "Semantic Error, ",
        "Semantic Error, Duplicate ",
        "Semantic Error, Undeclared "
    };


    errorQueue.push(messages[errorCategory] + message);
    
    switch (errorCategory) {
        case LEXICAL: lexicalErrors++; break;
        case SYNTAX: syntacticErrors++; break;
        case GENERAL_SEMANTIC: semanticErrors++; break;
        default: break;
    }
}

void displayErrors() {
    while (!errorQueue.empty()) {
        printf("%s\n", errorQueue.front().c_str());
        errorQueue.pop();
    }
}
